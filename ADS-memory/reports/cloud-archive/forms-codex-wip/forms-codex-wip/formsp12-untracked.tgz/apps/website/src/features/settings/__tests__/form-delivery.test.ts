import assert from 'node:assert/strict';
import { test } from 'node:test';
import { InMemorySettingsRepo, set } from '@jini-ai/core/settings';
import { ensureFormDeliverySettings, parseFormDeliveryBindings, readFormDeliveryBindings, readFormsAutoPull } from '../form-delivery.js';

const binding = { bindingId: 'a', adapterId: 'sheet', connectionRef: 'credential-id', enabled: true, config: { spreadsheet: 'id' } };

test('bindings use the existing settings ledger, default empty, while automatic pull defaults on', async () => {
  let n = 0;
  const settingsRepo = new InMemorySettingsRepo();
  const clock = { nowMs: () => 1000, nowIso: () => new Date(1000).toISOString() };
  const ids = { newId: () => `id-${++n}` };
  const principals = { findActiveById: async ({ id }: { id: string }) => ({ id }) };
  await ensureFormDeliverySettings({ deps: { settingsRepo, clock, ids, principals }, systemPrincipalId: 'system' });
  const input = { settingsRepo, workspaceId: 'w' };
  assert.deepEqual(await readFormDeliveryBindings(input), []); assert.equal(await readFormsAutoPull(input), true);
  const deps = { repo: settingsRepo, clock, ids, principals, authorize: async () => ({ allowed: true, reason: 'test' }) };
  await set({ deps, input: { namespace: 'core.forms', key: 'deliveryBindings', scope: 'workspace', workspaceId: 'w', authWorkspaceId: 'w', callerPrincipalId: 'owner', value: [binding] } });
  assert.deepEqual(await readFormDeliveryBindings(input), [binding]);
  await ensureFormDeliverySettings({ deps: { settingsRepo, clock, ids, principals }, systemPrincipalId: 'system' });
  assert.deepEqual(await readFormDeliveryBindings(input), [binding], 'next boot preserves bindings');
  assert.deepEqual(await readFormDeliveryBindings({ ...input, workspaceId: 'other' }), []);
});

test('invalid or duplicate bindings fail the whole list; empty form filter deliberately matches nothing', () => {
  assert.throws(() => parseFormDeliveryBindings({ value: [binding, binding] }));
  assert.throws(() => parseFormDeliveryBindings({ value: [{ ...binding, connectionRef: '' }] }));
  assert.throws(() => parseFormDeliveryBindings({ value: Array.from({ length: 101 }, (_, i) => ({ ...binding, bindingId: String(i) })) }));
  assert.deepEqual(parseFormDeliveryBindings({ value: [{ ...binding, formIds: [] }] })[0]!.formIds, []);
});
