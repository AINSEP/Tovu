import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createToolRegistry } from '@jini-ai/core';
import { createInMemoryEventLog, createRunLifecycle, createToolExecutor } from '@jini-ai/daemon';
import { delegatedToolExecuteRoute } from '@jini-ai/daemon/http';
import { executeCommand, InMemoryChangeSetRepo } from '#src/contracts/core/commands/index';
import { InMemoryFormDefinitionRepo, InMemoryFormSubmissionRepo } from '@jini-ai/cms/forms';
import { buildFormsRegistrations, type FormsToolDeps } from '../tool-registrations.js';

/** Exercise the public tool transport with a typed status fake, including the permission boundary. */
async function fixture(required: { allow: boolean }, _options = {}) {
  const reads: { workspaceId: string; submissionId: string }[] = [];
  const deps: FormsToolDeps = {
    workspaceId: 'w', executeCommand, clock: { nowMs: () => 0 }, idGen: { newId: () => 'unused' },
    authorize: async () => required.allow ? { allowed: true, reason: 'test' } : { allowed: false, reason: 'no_grant' },
    changeSets: new InMemoryChangeSetRepo(), formDefinitionRepo: new InMemoryFormDefinitionRepo(), formSubmissionRepo: new InMemoryFormSubmissionRepo(),
    outbox: { enqueue: async () => {}, claimPending: async () => [], markDelivered: async () => {}, markFailed: async () => {} },
    formDelivery: { status: { read: async input => { reads.push(input); return [{ bindingId: 'a', jobId: 'j', status: 'retrying', attempts: 2, nextRetryAt: '2026-10-20T01:00:00.000Z', error: 'rate-limited' }]; } } },
  };
  const registry = createToolRegistry({}); for (const registration of buildFormsRegistrations(deps)) registry.register(registration);
  const toolExecutor = createToolExecutor({ registry }); const lifecycle = createRunLifecycle({ eventLog: createInMemoryEventLog({}) });
  const { run } = await lifecycle.start({ contextRef: 'status-test' });
  return { reads, call: () => delegatedToolExecuteRoute.handle({ input: { runId: run.id, toolUseId: 'status', toolId: 'forms_delivery_status', input: { submissionId: 's' } },
    deps: { lifecycle, toolExecutor, resolvePrincipal: () => ({ id: 'operator' }) } }) };
}

test('status tool reads only the authenticated workspace through the status port', async () => {
  const f = await fixture({ allow: true }); const result = await f.call();
  assert.equal(result.ok, true); assert.deepEqual(f.reads, [{ workspaceId: 'w', submissionId: 's' }]);
  const text = JSON.stringify(result); assert.match(text, /rate-limited/); assert.match(text, /retrying/);
});

test('status tool refuses permission before reading delivery state', async () => {
  const f = await fixture({ allow: false }); const result = await f.call();
  assert.equal(result.ok, false); assert.deepEqual(f.reads, []);
});
