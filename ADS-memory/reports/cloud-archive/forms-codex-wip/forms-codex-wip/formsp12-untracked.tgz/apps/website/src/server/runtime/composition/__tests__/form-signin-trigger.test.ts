import '../../../../platform/site-dir/__tests__/helpers/isolated-catalog-home.js';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import express from 'express';
import { assignRole, createUser } from '@jini-ai/user-management/server';
import { createRouteDeps } from '../app.js';
import { notifyAdminSignIn, registerAuthRoutes } from '../../../inbound/admin-http/dev-auth.js';
import { identityServiceDepsFrom } from '../../../inbound/admin-http/routes/users/deps.js';
import { mintBootSessionToken } from '../../../../features/identity/boot-session-token.js';
import { startTestServer } from '../../../__tests__/helpers/http-test-server.js';

/** Real identity repositories prove owner/admin eligibility, rather than faking a permission bit. */
test('owner and built-in admin trigger pulls; an ordinary operator does not', async () => {
  const deps = createRouteDeps(); await deps.identityReady;
  const ownerId = await deps.ownerPrincipalId;
  const seen: string[] = []; deps.onAdminSignIn = ({ principalId }) => { seen.push(principalId); };
  await notifyAdminSignIn({ deps, principalId: ownerId });
  const service = identityServiceDepsFrom(deps);
  const { principal } = await createUser({ deps: service, input: { workspaceId: deps.workspaceId, callerPrincipalId: ownerId, username: 'forms-trigger-test', password: 'Test-only-Password-42!' } });
  await notifyAdminSignIn({ deps, principalId: principal.id });
  assert.deepEqual(seen, [ownerId]);
  const admin = await deps.roleRepo.findByName({ workspaceId: deps.workspaceId, name: 'admin' });
  assert.ok(admin);
  await assignRole({ deps: service, input: { workspaceId: deps.workspaceId, callerPrincipalId: ownerId, principalId: principal.id, roleId: admin.id } });
  await notifyAdminSignIn({ deps, principalId: principal.id });
  assert.deepEqual(seen, [ownerId, principal.id]);
});

test('desktop boot-session sign-in invokes the hook only after successful authentication', async t => {
  const deps = createRouteDeps(); await deps.identityReady;
  let signedIn!: () => void;
  const triggered = new Promise<void>(resolve => { signedIn = resolve; });
  let calls = 0; deps.onAdminSignIn = () => { calls++; signedIn(); };
  const app = express(); app.use(express.json()); registerAuthRoutes(app, deps);
  const base = await startTestServer(app, t);
  const request = (token: string) => fetch(`${base}/api/admin/v1/auth/boot-session`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ token }) });
  assert.equal((await request('invalid')).status, 401); assert.equal(calls, 0);
  const response = await request(mintBootSessionToken());
  assert.equal(response.status, 200); await triggered; assert.equal(calls, 1);
});
