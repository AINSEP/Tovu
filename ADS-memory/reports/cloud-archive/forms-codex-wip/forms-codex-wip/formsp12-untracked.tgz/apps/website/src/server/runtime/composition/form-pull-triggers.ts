import { createFormPullTrigger } from "@jini-ai/cms/forms";
/** Serving-only trigger wiring. All settings, debounce, leases and import behavior stay in pull. */
export interface ServingFormPullDeps {
  workspaceId: string;
  formSubmissionsAutoPull?: { run(required: { workspaceId: string }, optional?: Record<string, never>): Promise<void> };
  onAdminSignIn?: (required: { principalId: string }, optional?: Record<string, never>) => void;
}

/** Install after subscriptions, then perform one startup pass. Sign-ins call the same port.
 * The caller tracks work with the serving app's existing shutdown mechanism. No interval is used.
 * @example installServingFormPullTriggers({ deps, track: work => bootWork.push(work) });
 */
export function installServingFormPullTriggers(required: { deps: ServingFormPullDeps; track: (work: Promise<void>) => void },
  optional: { warn?: (message: string) => void } = {}): { stop(): Promise<void> } {
  const trigger = createFormPullTrigger({
    run: () => required.deps.formSubmissionsAutoPull?.run({ workspaceId: required.deps.workspaceId }) ?? Promise.resolve(),
    onError: () => (optional.warn ?? console.warn)('[form-submissions] automatic pull failed; retry at the next startup or sign-in'),
  });
  const triggerPull = (): void => {
    if (required.deps.formSubmissionsAutoPull) required.track(trigger.run({}));
  };
  required.deps.onAdminSignIn = () => triggerPull();
  triggerPull();
  return { stop: async () => { delete required.deps.onAdminSignIn; await trigger.stop({}); } };
}
