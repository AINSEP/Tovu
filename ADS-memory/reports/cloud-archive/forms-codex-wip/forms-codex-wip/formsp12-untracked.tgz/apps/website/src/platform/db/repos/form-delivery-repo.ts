/** SQL adapters for frozen delivery plans and receiver admission (ADR-066 migration 0019). */
import { safeFormDeliveryError, type FormDeliveryPlan, type FormDeliveryPlanPort, type FormDeliveryStatus, type FormDeliveryStatusPort, type FormPullLeasePort } from '@jini-ai/cms/forms';
import type { ContentKernel } from '../content-kernel.js';
import { outboxEventValues } from './outbox-repo.js';

/** One plan per workspace/submission, including zero jobs; one transaction owns every child insert. */
export class SqlFormDeliveryRepo implements FormDeliveryPlanPort, FormDeliveryStatusPort {
  constructor(private readonly required: { kernel: ContentKernel }, _options: Record<string, never> = {}) {}

  /** Concurrent/replayed source events reuse the committed JSON without rereading settings. */
  async once(input: Parameters<FormDeliveryPlanPort['once']>[0], _options: Record<string, never> = {}): Promise<FormDeliveryPlan> {
    const { kernel } = this.required;
    return kernel.transaction(async () => {
      await kernel.lockKey(JSON.stringify(['form-delivery', input.workspaceId, input.submissionId]));
      const stored = await kernel.run(db => db.selectFrom('form_delivery_plans').select('plan_json')
        .where('workspace_id', '=', input.workspaceId).where('submission_id', '=', input.submissionId).executeTakeFirst());
      if (stored) return JSON.parse(stored.plan_json) as FormDeliveryPlan;
      // Clone before persisting so caller-owned settings objects cannot mutate a returned plan.
      const plan = structuredClone(await input.build());
      if (plan.workspaceId !== input.workspaceId || plan.submissionId !== input.submissionId) throw new Error('Form delivery plan identity mismatch');
      await kernel.run(db => db.insertInto('form_delivery_plans')
        .values({ workspace_id: plan.workspaceId, submission_id: plan.submissionId, plan_json: JSON.stringify(plan) }).execute());
      for (const job of plan.jobs) {
        if (job.workspaceId !== plan.workspaceId || job.aggregateId !== plan.submissionId) throw new Error('Form delivery child identity mismatch');
        await kernel.run(db => db.insertInto('outbox_events').values(outboxEventValues(job)).execute());
        await kernel.run(db => db.insertInto('form_delivery_jobs').values({
          workspace_id: plan.workspaceId, submission_id: plan.submissionId, binding_id: job.payload.binding.bindingId, job_id: job.id,
        }).execute());
      }
      return plan;
    });
  }

  /** Status is a workspace-scoped join to the worker's ledger, never a parallel state machine. */
  async read(input: { workspaceId: string; submissionId: string }, _options: Record<string, never> = {}): Promise<readonly FormDeliveryStatus[]> {
    const rows = await this.required.kernel.run(db => db.selectFrom('form_delivery_jobs as j')
      .innerJoin('outbox_events as o', 'o.id', 'j.job_id').select(['j.binding_id', 'j.job_id', 'o.status', 'o.attempts', 'o.next_attempt_at', 'o.last_error'])
      .where('j.workspace_id', '=', input.workspaceId).where('o.workspace_id', '=', input.workspaceId).where('j.submission_id', '=', input.submissionId)
      .orderBy('j.binding_id').execute());
    return rows.map(row => deliveryStatus({ row }));
  }
}

/** A bounded pull has ten pages of timeout-bounded requests. A 30-minute lease permits crash
 * recovery without a polling loop. Like outbox claims, work still live past the lease can overlap;
 * plugin I/O must respect the host's request bounds. Release is fenced against a newer holder. */
export class SqlFormPullLeaseRepo implements FormPullLeasePort {
  constructor(private readonly required: { kernel: ContentKernel }, _options: Record<string, never> = {}) {}

  /** Serialize admission in every dialect, then persist lease and debounce timestamp together. */
  async claim(input: Parameters<FormPullLeasePort['claim']>[0], _options: Record<string, never> = {}): Promise<boolean> {
    const { kernel } = this.required;
    return kernel.transaction(async () => {
      await kernel.lockKey(JSON.stringify(['form-pull', input.workspaceId, input.receiverKey]));
      const row = await kernel.run(db => db.selectFrom('form_receiver_pulls').selectAll()
        .where('workspace_id', '=', input.workspaceId).where('receiver_key', '=', input.receiverKey).executeTakeFirst());
      if (row?.lease_token && row.lease_expires_at! > input.nowIso) return false;
      if (row?.last_started_at && Date.parse(input.nowIso) - Date.parse(row.last_started_at) < input.debounceMs) return false;
      const values = { workspace_id: input.workspaceId, receiver_key: input.receiverKey, lease_token: input.token,
        lease_expires_at: new Date(Date.parse(input.nowIso) + 30 * 60_000).toISOString(), last_started_at: input.nowIso };
      await kernel.run(db => db.insertInto('form_receiver_pulls').values(values)
        .onConflict(c => c.columns(['workspace_id', 'receiver_key']).doUpdateSet(values)).execute());
      return true;
    });
  }

  /** Only the holder can clear admission; retain last_started_at for subsequent sign-ins. */
  async release(input: Parameters<FormPullLeasePort['release']>[0], _options: Record<string, never> = {}): Promise<void> {
    await this.required.kernel.run(db => db.updateTable('form_receiver_pulls')
      .set({ lease_token: null, lease_expires_at: null }).where('workspace_id', '=', input.workspaceId)
      .where('receiver_key', '=', input.receiverKey).where('lease_token', '=', input.token).execute());
  }
}

/** Pure projection from the outbox ledger to the later admin/tool read model. */
function deliveryStatus(required: { row: { binding_id: string; job_id: string; status: string; attempts: number; next_attempt_at: string; last_error: string | null } }, _options = {}): FormDeliveryStatus {
  const { row } = required;
  const status = deliveryPhase({ status: row.status, attempts: row.attempts });
  return { bindingId: row.binding_id, jobId: row.job_id, status, attempts: row.attempts,
    nextRetryAt: row.status === 'pending' && row.attempts > 0 ? row.next_attempt_at : null,
    error: status !== 'completed' && row.last_error ? safeFormDeliveryError({ code: row.last_error }) : null };
}
/** Processing claims count as retrying; no second status ledger is maintained. */
function deliveryPhase(required: { status: string; attempts: number }, _options = {}): FormDeliveryStatus['status'] {
  if (required.status === 'delivered') return 'completed';
  if (required.status === 'failed') return 'failed';
  return required.attempts > 0 ? 'retrying' : 'pending';
}
