/** Forms/plugin bridge: generic durable orchestration lives in Jini; Tovu binds its plugin ABI. */
import { createFormDeliverySubscriptions, deliverFormJob, FormDeliveryError, planFormDeliveries,
  type FormDefinitionRepoPort, type FormSubmissionRepoPort, type FormDeliveryJob, type FormDeliveryPlanPort, type FormDeliveryStatusPort } from '@jini-ai/cms/forms';
import type { EventBusPort } from '@jini-ai/cms/core';
import type { SettingsRepoPort } from '@jini-ai/core/settings';
import type { Clock, IdGenerator } from '@jini-ai/core/primitives';
import { resolveCustomCredentialByLabel, type CustomCredentialWriteDeps } from '#src/features/custom-credentials/index';
import type { FormDeliveryConnectionPort } from '#src/features/form-destinations/types';
import type { FormDestinationKit, FormDestinationRegistry } from '#src/features/form-destinations/index';
import { buildFormDestinationManifest } from '#src/features/forms/form-destination-manifest';
import { readFormDeliveryBindings } from '#src/features/settings/form-delivery';

export interface FormDeliveryRuntimePort {
  start(required?: Record<string, never>, optional?: Record<string, never>): void;
  readonly status: FormDeliveryStatusPort;
}
export interface FormDeliveryCompositionDeps {
  workspaceId: string;
  bus: EventBusPort;
  plans: FormDeliveryPlanPort & FormDeliveryStatusPort;
  settingsRepo: SettingsRepoPort;
  formDefinitionRepo: Pick<FormDefinitionRepoPort, 'findById'>;
  formSubmissionRepo: Pick<FormSubmissionRepoPort, 'findById'>;
  resolveConnection: FormDeliveryConnectionPort;
  loadRegistry: (workspaceId: string) => Promise<FormDestinationRegistry>;
  kit: FormDestinationKit;
  clock: Clock;
  idGen: IdGenerator;
}

/** Bind planner, source readers and plugin delivery once. No subscriptions or I/O until start. */
export function composeFormDelivery(required: FormDeliveryCompositionDeps, _options: Record<string, never> = {}): FormDeliveryRuntimePort {
  const planner = {
    plans: required.plans,
    bindings: (input: { workspaceId: string }) => readFormDeliveryBindings({ ...input, settingsRepo: required.settingsRepo }),
    snapshot: (input: { workspaceId: string; submissionId: string; formDefinitionId: string }) => readSnapshot({ deps: required, ...input }),
    newId: () => required.idGen.newId(), nowIso: () => new Date(required.clock.nowMs()).toISOString(),
  };
  const subscriptions = createFormDeliverySubscriptions({ bus: required.bus,
    plan: input => {
      if (input.workspaceId !== required.workspaceId) throw new Error('Form delivery workspace mismatch');
      return planFormDeliveries({ deps: planner, ...input });
    },
    deliver: async input => {
      if (input.workspaceId !== required.workspaceId) throw new FormDeliveryError({ code: 'configuration-invalid', retryable: false });
      await deliverFormJob({ job: input.job, deliver: job => deliverToPlugin({ deps: required, workspaceId: input.workspaceId, job }) });
    },
  });
  return { start: subscriptions.start, status: required.plans };
}

/** Freeze the effective fields and stored answers, excluding IP and notification configuration. */
async function readSnapshot(required: { deps: FormDeliveryCompositionDeps; workspaceId: string; submissionId: string; formDefinitionId: string }, _options = {}) {
  const { deps, workspaceId, submissionId, formDefinitionId } = required;
  const definition = await deps.formDefinitionRepo.findById({ workspaceId, id: formDefinitionId });
  const submission = await deps.formSubmissionRepo.findById({ workspaceId, id: submissionId });
  if (!definition || !submission || submission.formDefinitionId !== definition.id) return null;
  const [form] = buildFormDestinationManifest({ definitions: [{ ...definition, status: 'active' }] });
  return { form: form!, submission: { id: submission.id, answers: submission.data, submittedAt: submission.submittedAt } };
}

/** Open only this binding's stable credential ID. The label resolver remains the vault owner;
 * verify its result ID too so concurrent label edits cannot silently substitute another account. */
async function deliverToPlugin(required: { deps: FormDeliveryCompositionDeps; workspaceId: string; job: FormDeliveryJob }, _options = {}) {
  const { deps, workspaceId, job } = required;
  const registry = await deps.loadRegistry(workspaceId);
  const adapter = registry.get(job.binding.adapterId);
  if (!adapter?.module.deliver) throw new FormDeliveryError({ code: 'adapter-unavailable', retryable: true });
  const credential = await deps.resolveConnection({ workspaceId, connectionRef: job.binding.connectionRef, adapterId: job.binding.adapterId });
  if (!credential) throw new FormDeliveryError({ code: 'authorization-required', retryable: false });
  return adapter.module.deliver({ kit: deps.kit, credential,
    ...job.snapshot, binding: job.binding, idempotencyKey: job.idempotencyKey });
}

/** Custom-credential adapter for stable connection IDs. OAuth connections can supply the same port
 * later. Reuse the vault owner to open secrets, then verify ID after label lookup to avoid substitution. */
export async function resolveFormDeliveryCredential(required: { credentials: CustomCredentialWriteDeps; workspaceId: string; connectionRef: string }, _options = {}) {
  const { credentials, workspaceId, connectionRef } = required;
  const record = await credentials.repo.findById({ workspaceId, id: connectionRef });
  const saved = record ? await resolveCustomCredentialByLabel(credentials, { workspaceId, label: record.label }) : null;
  return saved?.id === connectionRef ? { ...saved.connection, baseUrl: saved.baseUrl } : null;
}
