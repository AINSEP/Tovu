import { sql } from "kysely";
import type { StorageKernel } from "../kernel/port.js";
import type { MigrationStep } from "./step.js";

/** Frozen plans outlive local deletion; status remains owned by outbox_events. */
export function formDeliveryAndPullStatements(required: { dialect: 'sqlite' | 'postgres' }, _options: Record<string, never> = {}): readonly string[] {
  const jsonType = { sqlite: 'text', postgres: 'jsonb' }[required.dialect];
  return [
  `CREATE TABLE form_delivery_plans (workspace_id text NOT NULL, submission_id text NOT NULL, plan_json ${jsonType} NOT NULL, PRIMARY KEY (workspace_id, submission_id))`,
  "CREATE TABLE form_delivery_jobs (workspace_id text NOT NULL, submission_id text NOT NULL, binding_id text NOT NULL, job_id text NOT NULL, PRIMARY KEY (workspace_id, submission_id, binding_id))",
  "CREATE INDEX idx_form_delivery_binding ON form_delivery_jobs (workspace_id, binding_id)",
  "CREATE UNIQUE INDEX ux_form_delivery_job_id ON form_delivery_jobs (job_id)",
  "CREATE TABLE form_receiver_pulls (workspace_id text NOT NULL, receiver_key text NOT NULL, lease_token text, lease_expires_at text, last_started_at text, PRIMARY KEY (workspace_id, receiver_key))",
  ];
}

/** Apply fixed, portable DDL inside the ADR-066 runner's transaction. */
async function up(kernel: StorageKernel<unknown>): Promise<void> {
  for (const statement of formDeliveryAndPullStatements({ dialect: kernel.dialect })) await kernel.execute(sql.raw(statement));
}

/** Delivery plans and shared pull leases. @example formDeliveryAndPull({ checksum }) */
export function formDeliveryAndPull(required: { checksum: string }, _options: Record<string, never> = {}): MigrationStep {
  return { id: "0019_form_delivery_and_pull", checksum: required.checksum, up };
}
