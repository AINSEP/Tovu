import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import { installServingFormPullTriggers, type ServingFormPullDeps } from '../form-pull-triggers.js';

/** Behavioral test of the exact adapter called by createServingApp. */
test('serving startup and each authenticated sign-in invoke the existing automatic pull port', async () => {
  const seen: string[] = [];
  const tracked: Promise<void>[] = [];
  const deps: ServingFormPullDeps = { workspaceId: 'w', formSubmissionsAutoPull: { run: async ({ workspaceId }) => { seen.push(workspaceId); } } };
  installServingFormPullTriggers({ deps, track: work => tracked.push(work) });
  await Promise.all(tracked);
  assert.deepEqual(seen, ['w']);
  deps.onAdminSignIn?.({ principalId: 'owner' });
  await Promise.all(tracked);
  assert.deepEqual(seen, ['w', 'w']);
});

test('failed startup pull is observed, and a later sign-in can trigger again', async () => {
  const tracked: Promise<void>[] = []; const warnings: string[] = [];
  let calls = 0;
  const deps: ServingFormPullDeps = { workspaceId: 'w', formSubmissionsAutoPull: { run: async () => { calls++; throw new Error('private receiver address'); } } };
  installServingFormPullTriggers({ deps, track: work => tracked.push(work) }, { warn: message => warnings.push(message) });
  await Promise.all(tracked);
  deps.onAdminSignIn?.({ principalId: 'admin' });
  await Promise.all(tracked);
  assert.equal(calls, 2);
  assert.equal(warnings.length, 2);
  assert.ok(warnings.every(message => !message.includes('private')));
});

test('serving composition installs triggers after createApp subscriptions and before draining', () => {
  const source = readFileSync(new URL('../serving-app.ts', import.meta.url), 'utf8');
  const build = source.indexOf('const app = createApp(');
  const triggers = source.indexOf('installServingFormPullTriggers({');
  assert.ok(build >= 0 && triggers > build);
  assert.ok(source.indexOf('const outboxDrainer = startOutboxDrainer(') > triggers);
  const app = readFileSync(new URL('../app.ts', import.meta.url), 'utf8');
  assert.ok(!app.includes('installServingFormPullTriggers({'), 'exporter/eager apps never install triggers');
});
