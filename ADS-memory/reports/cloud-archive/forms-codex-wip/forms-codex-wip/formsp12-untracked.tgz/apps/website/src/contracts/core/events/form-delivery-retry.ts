import { computeBackoffMs, MAX_DELIVERY_ATTEMPTS } from "@jini-ai/integrations/webhooks";
/** Host retry selection only; the Jini outbox worker owns attempts, scheduling and terminal state. */
import { FORM_DELIVERY_EVENT, FormDeliveryError } from '@jini-ai/cms/forms';
import type { OutboxRetryPolicy, OutboxRetryPolicyResolver } from '@jini-ai/infra/events/outbox';

/** External delivery gets a longer window than in-process events; honor bounded provider delays. */
const deliveryRetry: OutboxRetryPolicy = {
  maxAttempts: MAX_DELIVERY_ATTEMPTS,
  retryable: ({ error }) => !(error instanceof FormDeliveryError) || error.retryable,
  backoffMs: ({ attempts, random, error }) => {
    const delay = computeBackoffMs({ attempts }, { random });
    const suggested = error instanceof FormDeliveryError ? error.retryAfterMs : undefined;
    return typeof suggested === 'number' && Number.isFinite(suggested) ? Math.max(delay, Math.min(24 * 60 * 60_000, suggested)) : delay;
  },
};
/** Every inline and background drain uses the same resolver. Other events retain Jini defaults. */
export const formDeliveryRetryPolicy: OutboxRetryPolicyResolver = ({ event }) => event.name === FORM_DELIVERY_EVENT ? deliveryRetry : undefined;
