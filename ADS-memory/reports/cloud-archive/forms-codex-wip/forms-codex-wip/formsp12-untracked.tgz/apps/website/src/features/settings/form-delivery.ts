/** Site delivery bindings and automatic receiver pulls use the existing settings ledger. */
import { ensureSettingDefinitions, getEffective, SCOPE_BIT, type EnsureSettingDefinitionsDeps, type SettingsRepoPort } from '@jini-ai/core/settings';
import type { FormDeliveryBinding } from '@jini-ai/cms/forms';

/** Register defaults without overwriting an owner's values. Bindings are list-shaped adapter data. */
export function ensureFormDeliverySettings(
  required: { deps: EnsureSettingDefinitionsDeps; systemPrincipalId: string }, _options: Record<string, never> = {},
): Promise<void> {
  return ensureSettingDefinitions(required.deps, { namespace: 'core.forms', systemPrincipalId: required.systemPrincipalId, definitions: [
    { key: 'deliveryBindings', schema: { type: 'json' }, defaultValue: [], scopes: SCOPE_BIT.workspace },
    { key: 'autoPull', schema: { type: 'boolean' }, defaultValue: true, scopes: SCOPE_BIT.workspace },
  ] });
}

/** Read fresh on every trigger. An unregistered definition has the owner-approved default, ON. */
export async function readFormsAutoPull(
  required: { settingsRepo: SettingsRepoPort; workspaceId: string }, _options: Record<string, never> = {},
): Promise<boolean> {
  const found = await getEffective({ repo: required.settingsRepo }, { namespace: 'core.forms', key: 'autoPull', scopeContext: { workspaceId: required.workspaceId } });
  return found?.value !== false;
}

/** Validate the JSON setting at its consumption boundary; invalid config never partially fans out.
 * At most 100 bindings, each with at most 1000 form IDs. Config contains non-secret adapter data.
 * @throws Error for malformed or duplicate bindings; settings are retried by the source outbox.
 */
export async function readFormDeliveryBindings(
  required: { settingsRepo: SettingsRepoPort; workspaceId: string }, _options: Record<string, never> = {},
): Promise<readonly FormDeliveryBinding[]> {
  const found = await getEffective({ repo: required.settingsRepo }, { namespace: 'core.forms', key: 'deliveryBindings', scopeContext: { workspaceId: required.workspaceId } });
  return parseFormDeliveryBindings({ value: found?.value ?? [] });
}

/** Pure validator, also usable by the later admin write adapter before committing the setting. */
export function parseFormDeliveryBindings(required: { value: unknown }, _options: Record<string, never> = {}): readonly FormDeliveryBinding[] {
  if (!Array.isArray(required.value) || required.value.length > 100) throw new Error('Invalid form delivery bindings');
  const seen = new Set<string>();
  return required.value.map(value => {
    if (!validBinding({ value }) || seen.has((value as FormDeliveryBinding).bindingId)) throw new Error('Invalid or duplicate form delivery binding');
    const binding = value as FormDeliveryBinding;
    seen.add(binding.bindingId);
    return { bindingId: binding.bindingId, adapterId: binding.adapterId, connectionRef: binding.connectionRef, enabled: binding.enabled,
      ...(binding.formIds === undefined ? {} : { formIds: [...binding.formIds] }), config: structuredClone(binding.config) };
  });
}

/** Validate identities separately from adapter config to keep each invariant inspectable. */
function validBinding(required: { value: unknown }, _options: Record<string, never> = {}): boolean {
  const value = required.value as Partial<FormDeliveryBinding> | null;
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  return validIdentity({ value }) && validConfig({ value }) && validFormIds({ value: value.formIds });
}
/** Stable references are nonempty bounded strings; configuration never holds a credential value. */
function validIdentity(required: { value: Partial<FormDeliveryBinding> }, _options: Record<string, never> = {}): boolean {
  return [required.value.bindingId, required.value.adapterId, required.value.connectionRef]
    .every(value => typeof value === 'string' && value.length > 0 && value.length <= 256);
}
/** Adapter-owned configuration is JSON object data. The ledger has already enforced JSON values. */
function validConfig(required: { value: Partial<FormDeliveryBinding> }, _options: Record<string, never> = {}): boolean {
  const { enabled, config } = required.value;
  return typeof enabled === 'boolean' && typeof config === 'object' && config !== null && !Array.isArray(config);
}
/** Absent means every form; an empty list deliberately matches no forms. */
function validFormIds(required: { value: unknown }, _options: Record<string, never> = {}): boolean {
  if (required.value === undefined) return true;
  return Array.isArray(required.value) && required.value.length <= 1000
    && required.value.every(value => typeof value === 'string' && value.length > 0 && value.length <= 256);
}
