import '../../../site-dir/__tests__/helpers/isolated-catalog-home.js';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { planFormDeliveries, FORM_DELIVERY_EVENT, FormDeliveryError, type FormDeliveryBinding, type FormDeliveryPlan } from '@jini-ai/cms/forms';
import { InMemoryEventBus } from '#src/contracts/core/events/index';
import { processOutbox } from '#src/contracts/core/events/outbox-worker';
import { describeEachDialect } from '#src/platform/db/kernel/__tests__/dialect-matrix';
import type { ContentKernel } from '../../content-kernel.js';
import { SqlFormDeliveryRepo, SqlFormPullLeaseRepo } from '../form-delivery-repo.js';
import { SqlOutboxAdapter } from '../outbox-repo.js';

const NOW = '2026-10-20T00:00:00.000Z';
const bindings: FormDeliveryBinding[] = ['a', 'b'].map(bindingId => ({ bindingId, adapterId: 'test', connectionRef: 'connection', enabled: true, config: { tab: bindingId } }));
function plan(input: { submissionId?: string } = {}): FormDeliveryPlan {
  const submissionId = input.submissionId ?? 's';
  return { workspaceId: 'w', submissionId, jobs: bindings.map(binding => ({ id: `${submissionId}-${binding.bindingId}`, name: FORM_DELIVERY_EVENT,
    workspaceId: 'w', aggregateId: submissionId, occurredAt: NOW, payload: { binding, idempotencyKey: JSON.stringify([submissionId, binding.bindingId]),
      snapshot: { form: { slug: 'test', fields: [] }, submission: { id: submissionId, answers: { note: 'hello' }, submittedAt: NOW } } } })) };
}

describeEachDialect('delivery planning and receiver leases', {
  tables: ['form_delivery_plans', 'form_delivery_jobs', 'form_receiver_pulls', 'outbox_events'],
  make: (kernel: ContentKernel) => ({ kernel, repo: new SqlFormDeliveryRepo({ kernel }), leases: new SqlFormPullLeaseRepo({ kernel }), outbox: new SqlOutboxAdapter(kernel) }),
}, make => {
  test('failure inserting any child rolls back the plan and every previous child', async () => {
    const { kernel, repo } = make(); const value = plan();
    const broken = { ...value, jobs: [value.jobs[0]!, value.jobs[0]!] };
    await assert.rejects(repo.once({ workspaceId: 'w', submissionId: 's', build: async () => broken }));
    const counts = await kernel.run(async db => {
      const extended = db;
      return [await extended.selectFrom('form_delivery_plans').selectAll().execute(), await extended.selectFrom('form_delivery_jobs').selectAll().execute(), await db.selectFrom('outbox_events').selectAll().execute()];
    });
    assert.deepEqual(counts, [[], [], []]);
    assert.deepEqual(await repo.once({ workspaceId: 'w', submissionId: 's', build: async () => value }), value);
  });

  test('concurrent/replayed events reuse one plan across repository recreation and settings changes', async () => {
    const { kernel, repo } = make(); let builds = 0;
    const input = { workspaceId: 'w', submissionId: 's', build: async () => { builds++; return plan(); } };
    const results = await Promise.all([repo.once(input), repo.once(input)]);
    assert.deepEqual(results[0], results[1]); assert.equal(builds, 1);
    const reopened = new SqlFormDeliveryRepo({ kernel });
    const again = await reopened.once({ ...input, build: async () => { throw new Error('settings changed'); } });
    assert.deepEqual(again, results[0]);
    assert.equal((await repo.read(input)).length, 2);
    assert.deepEqual(await repo.read({ ...input, workspaceId: 'other-workspace' }), []);
  });

  test('real planner freezes payload and settings under the SQL once boundary', async () => {
    const { repo } = make(); let selected = bindings; let snapshots = 0; let n = 0;
    const deps = { plans: repo, bindings: async () => selected,
      snapshot: async () => { snapshots++; return { form: { slug: 'contact', fields: [] }, submission: { id: 's', answers: { note: 'original' }, submittedAt: NOW } }; },
      newId: () => `job-${++n}`, nowIso: () => NOW };
    const input = { deps, workspaceId: 'w', submissionId: 's', formDefinitionId: 'form' };
    const first = await planFormDeliveries(input);
    selected = [{ ...bindings[0]!, config: { tab: 'changed' } }];
    const replay = await planFormDeliveries(input);
    assert.deepEqual(replay, first); assert.equal(snapshots, 1); assert.equal(n, 2);
    assert.equal(replay.jobs[0]!.payload.binding.config.tab, 'a');
  });

  test('failed child retries its original identity; siblings complete; status survives restart', async () => {
    const { kernel, repo, outbox } = make(); await repo.once({ workspaceId: 'w', submissionId: 's', build: async () => plan() });
    let now = Date.parse(NOW); let fail = true;
    const bus = new InMemoryEventBus(); const seen: string[] = [];
    await bus.subscribe<{ binding: FormDeliveryBinding; idempotencyKey: string }>({ eventName: FORM_DELIVERY_EVENT, handler: async event => {
      seen.push(`${event.id}:${event.payload.idempotencyKey}`);
      if (event.payload.binding.bindingId === 'a' && fail) throw new FormDeliveryError({ code: 'rate-limited', retryable: true, retryAfterMs: 90_000 });
    } });
    await processOutbox({ outbox, bus, clock: { nowMs: () => now } }, { random: () => 0 });
    const status = await repo.read({ workspaceId: 'w', submissionId: 's' });
    assert.equal(status[0]!.status, 'retrying'); assert.equal(status[0]!.attempts, 1);
    assert.equal(status[0]!.nextRetryAt, '2026-10-20T00:02:30.000Z'); assert.equal(status[0]!.error, 'rate-limited');
    assert.equal(status[1]!.status, 'completed');
    now += 150_000; fail = false;
    await processOutbox({ outbox: new SqlOutboxAdapter(kernel), bus, clock: { nowMs: () => now } });
    assert.deepEqual(seen, ['s-a:["s","a"]', 's-b:["s","b"]', 's-a:["s","a"]']);
    assert.deepEqual((await new SqlFormDeliveryRepo({ kernel }).read({ workspaceId: 'w', submissionId: 's' })).map(s => s.status), ['completed', 'completed']);
  });

  test('expired processing jobs recover after a crashed worker and bindings serialize independently', async () => {
    const { kernel, repo, outbox } = make();
    await repo.once({ workspaceId: 'w', submissionId: 's', build: async () => plan() });
    await repo.once({ workspaceId: 'w', submissionId: 't', build: async () => plan({ submissionId: 't' }) });
    const first = await outbox.claimPending({ batchSize: 20, nowIso: NOW });
    assert.deepEqual(first.map(row => row.id).sort(), ['s-a', 's-b']);
    assert.deepEqual(await new SqlOutboxAdapter(kernel).claimPending({ batchSize: 20, nowIso: NOW }), []);
    const recovered = await new SqlOutboxAdapter(kernel).claimPending({ batchSize: 20, nowIso: '2026-10-20T00:31:00.000Z' });
    assert.deepEqual(recovered.map(row => [row.id, row.attempts]).sort(), [['s-a', 2], ['s-b', 2]]);
    await outbox.markDelivered({ id: 's-b' });
    assert.deepEqual((await outbox.claimPending({ batchSize: 20, nowIso: NOW })).map(row => row.id), ['t-b']);
  });

  test('receiver leases debounce automatic pulls but allow manual after completion; releases are fenced', async () => {
    const { kernel, leases } = make();
    const input = { workspaceId: 'w', receiverKey: 'host:https://example.com', token: 'one', nowIso: NOW, debounceMs: 60_000 };
    assert.equal(await leases.claim(input), true);
    const restarted = new SqlFormPullLeaseRepo({ kernel });
    assert.equal(await restarted.claim({ ...input, token: 'two', debounceMs: 0 }), false);
    await leases.release(input);
    assert.equal(await restarted.claim({ ...input, token: 'two' }), false);
    assert.equal(await restarted.claim({ ...input, token: 'two', debounceMs: 0 }), true);
    await leases.release(input); // stale release must not clear token two
    assert.equal(await restarted.claim({ ...input, token: 'three', debounceMs: 0 }), false);
    assert.equal(await restarted.claim({ ...input, token: 'three', nowIso: '2026-10-20T00:31:00.000Z' }), true);
    assert.equal(await restarted.claim({ ...input, receiverKey: 'another-receiver' }), true);
  });
});
